# Employee Management MERN Website

## Requirements
- Node.js
- MongoDB running locally

## Run Backend
cd server
npm install
npm run dev

## Run Frontend
cd client
npm install
npm run dev

Open the URL shown by Vite (usually http://localhost:5173).
